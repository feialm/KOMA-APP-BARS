var myData = [
    {
        "id": "rust",
        "label": "rust",
        "value": 576,
        "color": "hsl(167, 70%, 50%)"
    },
    {
        "id": "javascript",
        "label": "javascript",
        "value": 129,
        "color": "hsl(119, 70%, 50%)"
    },
    {
        "id": "java",
        "label": "java",
        "value": 422,
        "color": "hsl(253, 70%, 50%)"
    },
    {
        "id": "hack",
        "label": "hack",
        "value": 71,
        "color": "hsl(307, 70%, 50%)"
    },
    {
        "id": "erlang",
        "label": "erlang",
        "value": 354,
        "color": "hsl(187, 70%, 50%)"
    }
];
export default myData;
